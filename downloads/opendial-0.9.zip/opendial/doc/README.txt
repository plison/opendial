
===========================
	OpenDial
	Version 0.9
===========================

Documentation on the OpenDial toolkit is available on the official website for the toolkit:
	http://opendial.googlecode.com
	
Main developer:
	Pierre Lison
	University of Oslo, Norway
	plison@ifi.uio.no
