
// =================================================================                                                                   
// Copyright (C) 2011-2013 Pierre Lison (plison@ifi.uio.no)                                                                            
//                                                                                                                                     
// This library is free software; you can redistribute it and/or                                                                       
// modify it under the terms of the GNU Lesser General Public License                                                                  
// as published by the Free Software Foundation; either version 2.1 of                                                                 
// the License, or (at your option) any later version.                                                                                 
//                                                                                                                                     
// This library is distributed in the hope that it will be useful, but                                                                 
// WITHOUT ANY WARRANTY; without even the implied warranty of                                                                          
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU                                                                    
// Lesser General Public License for more details.                                                                                     
//                                                                                                                                     
// You should have received a copy of the GNU Lesser General Public                                                                    
// License along with this program; if not, write to the Free Software                                                                 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA                                                                           
// 02111-1307, USA.                                                                                                                    
// =================================================================                                                                   
 
package opendial.plugins;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

import com.att.api.oauth.OAuthService;
import com.att.api.rest.APIResponse;
import com.att.api.rest.RESTClient;
import com.att.api.rest.RESTException;

import opendial.DialogueSystem;
import opendial.arch.DialException;
import opendial.arch.Logger;
import opendial.bn.distribs.discrete.CategoricalTable;
import opendial.bn.values.StringVal;
import opendial.bn.values.Value;
import opendial.datastructs.Assignment;
import opendial.datastructs.SpeechStream;
import opendial.gui.GUIFrame;
import opendial.modules.Module;
import opendial.modules.speech.SpeechRecogniser;
import opendial.modules.speech.SpeechSynthesiser;
import opendial.state.DialogueState;
import opendial.utils.AudioUtils;

/**
 * Plugin to access the AT&T Speech API for both speech recognition and synthesis.
 * The plugin necessitates the specification of an application ID and secret
 * [see the README file for the plugin for details].  The API offers
 * cloud-based services for AT&T's WATSON system.
 * 
 * <p>To enhance the recognition accuracy, it is recommended to provide the system
 * with a recognition grammar, which can be specified in the GRXML format.
 * 
 * @author  Pierre Lison (plison@ifi.uio.no)
 * @version $Date::                      $
 */
public class ATTSpeech implements Module, SpeechRecogniser, SpeechSynthesiser {
 
	// logger
	public static Logger log = new Logger("ATTSpeech", Logger.Level.DEBUG);

	/** Temporary file used to store the audio data */
	public static String TEMP_FILE = "resources/temp_att.wav";
	
	/** Root of the URL for the API */
	public static final String FQDN = "https://api.att.com";

	/** dialogue state */
	DialogueSystem system;
 
	/** REST client for the speech recognition */
	RESTClient asrClient;
	
	/** grammar file */
	File grammarFile;
	
	/** Rest client for the speech synthesis */
	RESTClient ttsClient;

	/** whether the system is paused or active */
	boolean paused = true;


	/**
	 * Creates a new plugin, attached to the dialogue system
	 * 
	 * @param system the dialogue system to attach
	 * @throws DialException
	 */
	public ATTSpeech(DialogueSystem system) throws DialException {
		this.system = system;
		List<String> missingParams = new LinkedList<String>();
		
		for (String requiredParam : Arrays.asList("id", "secret")) {
			if (!system.getSettings().params.containsKey(requiredParam)) {
				missingParams.add(requiredParam);
			}
		}
		if (!missingParams.isEmpty()) {
			throw new MissingParameterException(missingParams);
		}
		
		buildClients();
		
		if (system.getSettings().params.containsKey("grammar")) {
			File f = new File(system.getSettings().params.getProperty("grammar"));
			if (!f.exists()) {
				f = new File((new File(system.getDomain().getName()).getParent() +
						"/" + system.getSettings().params.getProperty("grammar")));
			}
			if (f.exists()) {
				grammarFile = f;
				log.info("AT&T Speech API will be used with the grammar: " + grammarFile.getPath());
			}
			else {
				log.warning("Grammar file " + f.getPath() + " cannot be found");
				log.info("AT&T Speech API will be used without grammar");
			}
		}
		else {
			log.info("AT&T Speech API will be used without grammar");
		}
	} 

	/**
	 * Starts the AT&T speech plugin.
	 */
	@Override
	public void start() throws DialException {
		paused = false;
		GUIFrame gui = system.getModule(GUIFrame.class);
		if (gui == null) {
			throw new DialException("AT&T connection requires access to the GUI");
		}
			
		// quick hack to ensure that the audio capture works 
		try {
		SpeechStream firstStream = new SpeechStream(system.getSettings().inputMixer);
		Thread.sleep(100);
		firstStream.close(); 
		}
		catch (Exception e) { 
			e.printStackTrace();
		}
	}


	/**
	 * Pauses the plugin.
	 */
	@Override
	public void pause(boolean toPause) {
		paused = toPause;
	}


	/**
	 * Returns true if the plugin has been started and is not paused.
	 */
	@Override
	public boolean isRunning() {
		return !paused;
	}


	/**
	 * Processes the speech input and updates the dialogue state
	 * as a result.
	 */
	@Override
	public void processInput(SpeechStream stream) {	
		if (!paused) {
		(new Thread(new RecognitionProcess(stream))).start();
		}
	}


	/**
	 * If the system output has been updated, trigger the speech synthesis.
	 */
	@Override
	public void trigger(DialogueState state, Collection<String> updatedVars) {
		String outputVar = system.getSettings().systemOutput;
		if (updatedVars.contains(outputVar) && state.hasChanceNode(outputVar) && !paused) {
			Value utteranceVal = system.getContent(outputVar).toDiscrete().getBest().getValue(outputVar);
			if (utteranceVal instanceof StringVal) {
			synthesise(utteranceVal.toString());
			}
		}
	}

	/**
	 * Processes the audio data contained in tempFile (based on the recognition
	 * grammar whenever provided) and returns the corresponding N-Best list
	 * of results.
	 * 
	 * @param tempFile the temporary WAV file containing the audio data
	 * @param grammar the recognition grammar, which can be null
	 * @return the corresponding N-Best list of recognition hypotheses
	 */
	private CategoricalTable recognise(File tempFile, File grammarFile) {

		CategoricalTable table = new CategoricalTable();
		String userVar = system.getSettings().userInput;
		log.info("calling AT&T server for recognition...\t");       
		try {

			Map<String,String> parts = new LinkedHashMap<String,String>();
			if (grammarFile != null && grammarFile.exists()) {
				parts.put(grammarFile.getAbsolutePath(), "x-grammar");
			}
			parts.put(tempFile.getAbsolutePath(), "x-voice");

			APIResponse apiResponse = asrClient.httpPost(parts.keySet().toArray(new String[parts.size()]), 
					"x-srgs-audio", parts.values().toArray(new String[parts.size()]));

			JSONObject object = new JSONObject(apiResponse.getResponseBody());
			JSONObject recognition = object.getJSONObject("Recognition");
			final String jStatus = recognition.getString("Status");

			if (jStatus.equals("OK")) {
				JSONArray nBest = recognition.getJSONArray("NBest");
				for (int i = 0; i < nBest.length(); ++i) {
					JSONObject nBestObject = (JSONObject) nBest.get(i);
					if (nBestObject.has("Hypothesis") && nBestObject.has("Confidence")) {
						String hyp = nBestObject.getString("Hypothesis");
						Double conf = nBestObject.getDouble("Confidence");
						table.addRow(new Assignment(userVar, hyp), conf);
					}
				}
			}

		} catch (RESTException re) {
			re.printStackTrace();
		} 
		return table;
	}




	/**
	 * Performs remote speech synthesis with the given utterance, and plays it on the 
	 * standard audio output.
	 * 
	 * @param utterance the utterance to synthesis
	 */
	@Override
	public void synthesise(String utterance) {
		try {
			log.info("calling AT&T server for synthesis...\t");       
			APIResponse apiResponse = ttsClient.httpPost(utterance);

        int statusCode = apiResponse.getStatusCode();
        if (statusCode == 200 || statusCode == 201) {
        	byte[] wavBytes = apiResponse.getResponseBody().getBytes("ISO-8859-1");
        	AudioUtils.playAudio(new ByteArrayInputStream(wavBytes), system.getSettings().outputMixer);
        	
        } else if (statusCode == 401) {
            throw new IOException("Unauthorized request.");
        } else {
            log.warning("TTS error: " + apiResponse);
        }
        
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	/**
	 * Builds the REST clients for speech recognition and synthesis.
	 * 
	 * @throws DialException
	 */
	private void buildClients() throws DialException {

		String id = system.getSettings().params.getProperty("id");
		String secret = system.getSettings().params.getProperty("secret");
		try {
			// Create service for interacting with the Speech api
			OAuthService osrvc = new OAuthService(FQDN, id, secret);
			asrClient = new RESTClient(FQDN + "/speech/v3/speechToTextCustom")
			.addAuthorizationHeader(osrvc.getToken("STTC"))
			.addHeader("Accept", "application/json")
			.addHeader("X-Arg", "HasMultipleNBest=true");
			
			ttsClient = new RESTClient(FQDN + "/speech/v3/textToSpeech")
			.addAuthorizationHeader(osrvc.getToken("TTS"))
		     .addHeader("Content-Type", "text/plain")
	         .addHeader("Accept", "audio/x-wav");    
			
		} catch (RESTException e) {
			throw new DialException("Cannot access AT&T API with the following credentials: " + id + " --> " + secret);
		}
	}
	

	/**
	 * Thread for a speech recognition process
	 */
	class RecognitionProcess implements Runnable {

		SpeechStream stream;
		
		public RecognitionProcess(SpeechStream stream) {
			this.stream = stream;
		}

		@Override
		public void run() {
			
			// the stream must be marked as completed
			synchronized (stream) {
			if (!stream.isClosed()) {
					try { stream.wait(); } 
					catch (InterruptedException e) { }
				}
			}
			try {
				File tempFile = new File(TEMP_FILE);
				if (tempFile.exists()) {
					tempFile.delete();
				} 
				stream.generateFile(tempFile);
				CategoricalTable nbest = recognise(tempFile, grammarFile); 
				if (!nbest.isEmpty()) {
					log.debug("recognition complete, results: " + nbest);
					system.addContent(nbest);
				}
			}
			catch (Exception e) {
				log.warning("cannot do recognition: " + e);
			}
			}
	}
	

}

