// =================================================================                                                                   
// Copyright (C) 2011-2015 Pierre Lison (plison@ifi.uio.no)
                                                                            
// Permission is hereby granted, free of charge, to any person 
// obtaining a copy of this software and associated documentation 
// files (the "Software"), to deal in the Software without restriction, 
// including without limitation the rights to use, copy, modify, merge, 
// publish, distribute, sublicense, and/or sell copies of the Software, 
// and to permit persons to whom the Software is furnished to do so, 
// subject to the following conditions:

// The above copyright notice and this permission notice shall be 
// included in all copies or substantial portions of the Software.

// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
// IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
// CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, 
// TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
// =================================================================                                                                   

package opendial;

import java.util.HashMap;
import java.util.Map;

import opendial.bn.distribs.CategoricalTable;
import opendial.bn.distribs.ProbDistribution;
import opendial.bn.nodes.ChanceNode;
import opendial.bn.values.ValueFactory;
import opendial.datastructs.Assignment;

public class Sandbox {

	
	public static void main(String[] args) throws InterruptedException {
		DialogueSystem system = new DialogueSystem();
		system.startSystem();
		
		Map<String,Double> nbestList1 = new HashMap<String,Double>();
		nbestList1.put("this is", 0.7);
		nbestList1.put("these", 0.3);
		system.addIncrementalUserInput(nbestList1, false);
		
		Map<String,Double> nbestList2 = new HashMap<String,Double>();
		nbestList2.put("a screw", 0.6);
		system.addIncrementalUserInput(nbestList2, true);
		
		Thread.sleep(10000);

		CategoricalTable ct = new CategoricalTable("u_u");
		ct.addRow(ValueFactory.create("state1"),0.4);
		system.getState().getChanceNode("u_u").setDistrib(ct);
	}
}
